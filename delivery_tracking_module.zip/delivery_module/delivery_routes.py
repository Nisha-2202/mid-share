# ─────────────────────────────────────────────────────────────
#  delivery_routes.py  —  Delivery Tracking Module for MediShare
#
#  Register in app.py:
#    from delivery_routes import delivery_bp
#    app.register_blueprint(delivery_bp)
# ─────────────────────────────────────────────────────────────

from flask import (Blueprint, render_template, request,
                   redirect, url_for, session, flash, jsonify)
import psycopg2, psycopg2.extras, os, random, string
from datetime import datetime

delivery_bp = Blueprint('delivery', __name__, url_prefix='/delivery')

# ── DB ────────────────────────────────────────────────────────
def get_db():
    return psycopg2.connect(
        os.environ.get('DATABASE_URL'),
        cursor_factory=psycopg2.extras.RealDictCursor
    )

# ── Auth guards ───────────────────────────────────────────────
def login_required(f):
    from functools import wraps
    @wraps(f)
    def dec(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please login to continue.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return dec

def admin_required(f):
    from functools import wraps
    @wraps(f)
    def dec(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return dec

# ── Generate unique delivery code ─────────────────────────────
def gen_delivery_code():
    year = datetime.now().year
    suffix = ''.join(random.choices(string.digits, k=4))
    return f'MS-DEL-{year}-{suffix}'


# ══════════════════════════════════════════════════════════════
#  PUBLIC TRACKING PAGE (no login needed — share the code)
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/track', methods=['GET', 'POST'])
def public_track():
    """Anyone with a delivery code can track their shipment."""
    delivery = None
    events   = []
    code     = ''
    error    = ''

    if request.method == 'POST' or request.args.get('code'):
        code = (request.form.get('code') or request.args.get('code', '')).strip().upper()
        if code:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("""
                SELECT d.*,
                       u_ngo.username   AS ngo_name,
                       u_donor.username AS donor_name,
                       nr.medicine_name, nr.quantity_needed
                FROM deliveries d
                LEFT JOIN users u_ngo   ON u_ngo.id   = d.ngo_id
                LEFT JOIN users u_donor ON u_donor.id = d.donor_id
                LEFT JOIN ngo_requests nr ON nr.id    = d.ngo_request_id
                WHERE d.delivery_code = %s
            """, (code,))
            delivery = cur.fetchone()

            if delivery:
                cur.execute("""
                    SELECT e.*, u.username AS updated_by_name
                    FROM delivery_events e
                    LEFT JOIN users u ON u.id = e.updated_by
                    WHERE e.delivery_id = %s
                    ORDER BY e.created_at ASC
                """, (delivery['id'],))
                events = cur.fetchall()
            else:
                error = f'No delivery found with code "{code}". Please check and try again.'
            conn.close()

    return render_template('delivery/public_track.html',
                           delivery=delivery, events=events,
                           code=code, error=error)


# ══════════════════════════════════════════════════════════════
#  NGO — VIEW MY DELIVERIES
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/my')
@login_required
def my_deliveries():
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("""
        SELECT d.*, nr.medicine_name, nr.quantity_needed,
               u.username AS donor_name
        FROM deliveries d
        JOIN ngo_requests nr ON nr.id    = d.ngo_request_id
        LEFT JOIN users u   ON u.id      = d.donor_id
        WHERE d.ngo_id = %s
        ORDER BY d.created_at DESC
    """, (session['user_id'],))
    deliveries = cur.fetchall()
    conn.close()
    return render_template('delivery/my_deliveries.html', deliveries=deliveries)


# ══════════════════════════════════════════════════════════════
#  NGO — VIEW SINGLE DELIVERY DETAIL
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/<int:del_id>')
@login_required
def detail(del_id):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("""
        SELECT d.*,
               u_ngo.username   AS ngo_name,
               u_donor.username AS donor_name,
               nr.medicine_name, nr.quantity_needed, nr.purpose
        FROM deliveries d
        LEFT JOIN users u_ngo   ON u_ngo.id   = d.ngo_id
        LEFT JOIN users u_donor ON u_donor.id = d.donor_id
        LEFT JOIN ngo_requests nr ON nr.id    = d.ngo_request_id
        WHERE d.id = %s
    """, (del_id,))
    delivery = cur.fetchone()

    # Security: NGOs can only see their own; donors can see theirs; admin sees all
    if not delivery:
        flash('Delivery not found.', 'danger')
        return redirect(url_for('delivery.my_deliveries'))
    if session.get('role') not in ('admin',) and \
       delivery['ngo_id'] != session['user_id'] and \
       delivery.get('donor_id') != session['user_id']:
        flash('Access denied.', 'danger')
        return redirect(url_for('delivery.my_deliveries'))

    cur.execute("""
        SELECT e.*, u.username AS updated_by_name
        FROM delivery_events e
        LEFT JOIN users u ON u.id = e.updated_by
        WHERE e.delivery_id = %s
        ORDER BY e.created_at ASC
    """, (del_id,))
    events = cur.fetchall()
    conn.close()
    return render_template('delivery/detail.html', delivery=delivery, events=events)


# ══════════════════════════════════════════════════════════════
#  NGO — CONFIRM RECEIPT
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/<int:del_id>/confirm_receipt', methods=['POST'])
@login_required
def confirm_receipt(del_id):
    conn = get_db()
    cur  = conn.cursor()

    cur.execute("SELECT * FROM deliveries WHERE id=%s AND ngo_id=%s",
                (del_id, session['user_id']))
    d = cur.fetchone()
    if not d or d['status'] != 'Out_for_Delivery':
        flash('Cannot confirm — delivery is not yet out for delivery.', 'warning')
        conn.close()
        return redirect(url_for('delivery.detail', del_id=del_id))

    now = datetime.now()
    cur.execute("""
        UPDATE deliveries SET status='Delivered', delivered_at=%s WHERE id=%s
    """, (now, del_id))
    # Mark NGO request as fulfilled
    cur.execute("""
        UPDATE ngo_requests SET status='Fulfilled', fulfilled_at=%s
        WHERE id=%s
    """, (now, d['ngo_request_id']))
    # Log event
    cur.execute("""
        INSERT INTO delivery_events (delivery_id, stage, note, updated_by, created_at)
        VALUES (%s,'Delivered','NGO confirmed receipt of medicines.',%s,%s)
    """, (del_id, session['user_id'], now))
    conn.commit()
    conn.close()
    flash('Thank you! Delivery confirmed as received. 🎉', 'success')
    return redirect(url_for('delivery.detail', del_id=del_id))


# ══════════════════════════════════════════════════════════════
#  ADMIN — ALL DELIVERIES DASHBOARD
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/admin')
@admin_required
def admin_dashboard():
    status_filter = request.args.get('status', 'all')
    conn = get_db()
    cur  = conn.cursor()

    where = "" if status_filter == 'all' else "WHERE d.status = %s"
    params = () if status_filter == 'all' else (status_filter,)

    cur.execute(f"""
        SELECT d.*, nr.medicine_name, nr.quantity_needed,
               u_ngo.username   AS ngo_name,
               u_donor.username AS donor_name
        FROM deliveries d
        LEFT JOIN ngo_requests nr ON nr.id    = d.ngo_request_id
        LEFT JOIN users u_ngo     ON u_ngo.id = d.ngo_id
        LEFT JOIN users u_donor   ON u_donor.id = d.donor_id
        {where}
        ORDER BY d.created_at DESC
    """, params)
    deliveries = cur.fetchall()

    # Status counts
    cur.execute("""
        SELECT status, COUNT(*) AS cnt FROM deliveries GROUP BY status
    """)
    counts = {r['status']: r['cnt'] for r in cur.fetchall()}
    counts['all'] = sum(counts.values())

    # Approved NGO requests without a delivery yet (ready to dispatch)
    cur.execute("""
        SELECT nr.*, u.username AS ngo_name, don.medicine_name AS d_medicine,
               don.city AS d_city
        FROM ngo_requests nr
        JOIN users u ON u.id = nr.ngo_id
        LEFT JOIN donations don ON don.id = nr.donation_id
        WHERE nr.status = 'Approved'
          AND nr.delivery_id IS NULL
        ORDER BY nr.approved_at ASC
    """)
    pending_dispatch = cur.fetchall()
    conn.close()

    return render_template('delivery/admin_dashboard.html',
                           deliveries=deliveries, counts=counts,
                           status_filter=status_filter,
                           pending_dispatch=pending_dispatch)


# ══════════════════════════════════════════════════════════════
#  ADMIN — CREATE DELIVERY for an approved NGO request
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/admin/create/<int:req_id>', methods=['POST'])
@admin_required
def admin_create(req_id):
    pickup_address   = request.form.get('pickup_address', '').strip()
    delivery_address = request.form.get('delivery_address', '').strip()
    city             = request.form.get('city', '').strip()
    courier_name     = request.form.get('courier_name', '').strip()
    courier_phone    = request.form.get('courier_phone', '').strip()
    admin_notes      = request.form.get('admin_notes', '').strip()

    conn = get_db()
    cur  = conn.cursor()

    # Fetch request details
    cur.execute("""
        SELECT nr.*, don.donor_id
        FROM ngo_requests nr
        LEFT JOIN donations don ON don.id = nr.donation_id
        WHERE nr.id = %s AND nr.status = 'Approved'
    """, (req_id,))
    req = cur.fetchone()
    if not req:
        flash('Request not found or not approved.', 'danger')
        conn.close()
        return redirect(url_for('delivery.admin_dashboard'))

    # Generate unique delivery code
    code = gen_delivery_code()
    while True:
        cur.execute("SELECT id FROM deliveries WHERE delivery_code=%s", (code,))
        if not cur.fetchone():
            break
        code = gen_delivery_code()

    now = datetime.now()
    cur.execute("""
        INSERT INTO deliveries
            (delivery_code, ngo_request_id, donation_id, ngo_id, donor_id,
             status, pickup_address, delivery_address, city,
             courier_name, courier_phone, admin_notes, packed_at, created_at)
        VALUES (%s,%s,%s,%s,%s,'Packed',%s,%s,%s,%s,%s,%s,%s,%s)
        RETURNING id
    """, (code, req_id, req['donation_id'], req['ngo_id'],
          req.get('donor_id'), pickup_address, delivery_address,
          city, courier_name, courier_phone, admin_notes, now, now))
    del_id = cur.fetchone()['id']

    # Link delivery back to request
    cur.execute("UPDATE ngo_requests SET delivery_id=%s WHERE id=%s", (del_id, req_id))

    # Log first event
    cur.execute("""
        INSERT INTO delivery_events (delivery_id, stage, note, updated_by, created_at)
        VALUES (%s,'Packed',%s,%s,%s)
    """, (del_id, f'Delivery created. Courier: {courier_name or "TBD"}',
          session['user_id'], now))

    conn.commit()
    conn.close()
    flash(f'Delivery {code} created successfully! Share code with NGO.', 'success')
    return redirect(url_for('delivery.admin_update', del_id=del_id))


# ══════════════════════════════════════════════════════════════
#  ADMIN — UPDATE DELIVERY STATUS
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/admin/<int:del_id>/update', methods=['GET', 'POST'])
@admin_required
def admin_update(del_id):
    conn = get_db()
    cur  = conn.cursor()

    if request.method == 'POST':
        new_status = request.form['status']
        note       = request.form.get('note', '').strip()
        courier    = request.form.get('courier_name', '').strip()
        courier_ph = request.form.get('courier_phone', '').strip()
        valid_statuses = ['Packed','Dispatched','Out_for_Delivery','Delivered','Failed']

        if new_status not in valid_statuses:
            flash('Invalid status.', 'danger')
            conn.close()
            return redirect(url_for('delivery.admin_update', del_id=del_id))

        now = datetime.now()
        # Build SET clause dynamically
        time_col = {
            'Dispatched':        'dispatched_at',
            'Out_for_Delivery':  'out_for_delivery_at',
            'Delivered':         'delivered_at',
            'Failed':            'failed_at',
        }.get(new_status)

        if time_col:
            cur.execute(f"""
                UPDATE deliveries
                SET status=%s, {time_col}=%s,
                    courier_name=COALESCE(NULLIF(%s,''), courier_name),
                    courier_phone=COALESCE(NULLIF(%s,''), courier_phone)
                WHERE id=%s
            """, (new_status, now, courier, courier_ph, del_id))
        else:
            cur.execute("""
                UPDATE deliveries SET status=%s WHERE id=%s
            """, (new_status, del_id))

        # If delivered, mark NGO request as fulfilled too
        if new_status == 'Delivered':
            cur.execute("SELECT ngo_request_id FROM deliveries WHERE id=%s", (del_id,))
            req_id = cur.fetchone()['ngo_request_id']
            cur.execute("""
                UPDATE ngo_requests SET status='Fulfilled', fulfilled_at=%s WHERE id=%s
            """, (now, req_id))

        # Log event
        cur.execute("""
            INSERT INTO delivery_events (delivery_id, stage, note, updated_by, created_at)
            VALUES (%s, %s, %s, %s, %s)
        """, (del_id, new_status, note or f'Status updated to {new_status}.',
              session['user_id'], now))

        conn.commit()
        flash(f'Delivery updated to {new_status}.', 'success')

    # Fetch delivery + events
    cur.execute("""
        SELECT d.*, nr.medicine_name, nr.quantity_needed,
               u_ngo.username AS ngo_name, u_ngo.id AS ngo_uid
        FROM deliveries d
        JOIN ngo_requests nr ON nr.id = d.ngo_request_id
        JOIN users u_ngo     ON u_ngo.id = d.ngo_id
        WHERE d.id = %s
    """, (del_id,))
    delivery = cur.fetchone()

    cur.execute("""
        SELECT e.*, u.username AS updated_by_name
        FROM delivery_events e
        LEFT JOIN users u ON u.id = e.updated_by
        WHERE e.delivery_id = %s ORDER BY e.created_at ASC
    """, (del_id,))
    events = cur.fetchall()
    conn.close()

    if not delivery:
        flash('Delivery not found.', 'danger')
        return redirect(url_for('delivery.admin_dashboard'))

    return render_template('delivery/admin_update.html',
                           delivery=delivery, events=events)


# ══════════════════════════════════════════════════════════════
#  API — JSON status for live polling
# ══════════════════════════════════════════════════════════════
@delivery_bp.route('/api/<delivery_code>')
def api_status(delivery_code):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("""
        SELECT d.delivery_code, d.status, d.courier_name, d.courier_phone,
               d.packed_at, d.dispatched_at, d.out_for_delivery_at,
               d.delivered_at, d.city, nr.medicine_name, nr.quantity_needed,
               u.username AS ngo_name
        FROM deliveries d
        JOIN ngo_requests nr ON nr.id = d.ngo_request_id
        JOIN users u ON u.id = d.ngo_id
        WHERE d.delivery_code = %s
    """, (delivery_code.upper(),))
    row = cur.fetchone()
    conn.close()
    if not row:
        return jsonify({'error': 'Not found'}), 404

    def fmt(dt):
        return dt.strftime('%d %b %Y, %I:%M %p') if dt else None

    return jsonify({
        'code':          row['delivery_code'],
        'status':        row['status'],
        'medicine':      row['medicine_name'],
        'quantity':      row['quantity_needed'],
        'ngo':           row['ngo_name'],
        'courier':       row['courier_name'],
        'courier_phone': row['courier_phone'],
        'city':          row['city'],
        'packed_at':         fmt(row['packed_at']),
        'dispatched_at':     fmt(row['dispatched_at']),
        'out_for_delivery_at': fmt(row['out_for_delivery_at']),
        'delivered_at':      fmt(row['delivered_at']),
    })
