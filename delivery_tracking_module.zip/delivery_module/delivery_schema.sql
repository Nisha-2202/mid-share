-- ─────────────────────────────────────────────────────────────
--  Delivery Tracking Module — Database Schema
--  Run AFTER ngo_schema.sql (depends on ngo_requests + donations)
-- ─────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS deliveries (
    id              SERIAL PRIMARY KEY,
    delivery_code   TEXT UNIQUE NOT NULL,   -- e.g. MS-DEL-2025-0042
    ngo_request_id  INTEGER NOT NULL REFERENCES ngo_requests(id) ON DELETE CASCADE,
    donation_id     INTEGER REFERENCES donations(id) ON DELETE SET NULL,
    ngo_id          INTEGER NOT NULL REFERENCES users(id),
    donor_id        INTEGER REFERENCES users(id),

    -- Current stage
    status          TEXT NOT NULL DEFAULT 'Packed'
                    CHECK (status IN ('Packed','Dispatched','Out_for_Delivery','Delivered','Failed')),

    -- Addresses
    pickup_address  TEXT,
    delivery_address TEXT,
    city            TEXT,

    -- Volunteer / courier
    courier_name    TEXT,
    courier_phone   TEXT,

    -- Timestamps for each stage
    packed_at       TIMESTAMP DEFAULT NOW(),
    dispatched_at   TIMESTAMP,
    out_for_delivery_at TIMESTAMP,
    delivered_at    TIMESTAMP,
    failed_at       TIMESTAMP,

    -- Notes
    admin_notes     TEXT,
    failure_reason  TEXT,

    created_at      TIMESTAMP DEFAULT NOW()
);

-- Delivery timeline events (full history log)
CREATE TABLE IF NOT EXISTS delivery_events (
    id            SERIAL PRIMARY KEY,
    delivery_id   INTEGER NOT NULL REFERENCES deliveries(id) ON DELETE CASCADE,
    stage         TEXT NOT NULL,
    note          TEXT,
    updated_by    INTEGER REFERENCES users(id),   -- admin user id
    created_at    TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_deliveries_code       ON deliveries(delivery_code);
CREATE INDEX IF NOT EXISTS idx_deliveries_ngo_id     ON deliveries(ngo_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_status     ON deliveries(status);
CREATE INDEX IF NOT EXISTS idx_delivery_events_delid ON delivery_events(delivery_id);

-- Update ngo_requests to link delivery when created
ALTER TABLE ngo_requests ADD COLUMN IF NOT EXISTS delivery_id INTEGER REFERENCES deliveries(id);
