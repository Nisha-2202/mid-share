# Delivery Tracking Module — Integration Guide

## Files to add to your project

```
your_project/
├── app.py                              ← Add 2 lines (see Step 2)
├── delivery_routes.py                  ← NEW — copy from this folder
├── delivery_schema.sql                 ← NEW — run on your database
└── templates/
    └── delivery/                       ← NEW — copy entire folder
        ├── public_track.html           (anyone can track by code)
        ├── my_deliveries.html          (NGO — view all deliveries)
        ├── detail.html                 (NGO — single delivery detail)
        ├── admin_dashboard.html        (Admin — manage all deliveries)
        └── admin_update.html           (Admin — update status)
```

## Step 1 — Run schema on your PostgreSQL database
```bash
psql "your_db_url" < delivery_schema.sql
```
> Must run AFTER ngo_schema.sql (depends on ngo_requests table)

## Step 2 — Register blueprint in app.py
```python
from delivery_routes import delivery_bp
app.register_blueprint(delivery_bp)
```

## Step 3 — Add nav links to your base template
```html
<!-- For all logged-in users -->
<a href="/delivery/track">Track Delivery</a>

<!-- For NGO users -->
{% if session.get('role') == 'ngo' %}
<a href="/delivery/my">My Deliveries</a>
{% endif %}

<!-- For admin -->
{% if session.get('role') == 'admin' %}
<a href="/delivery/admin">Manage Deliveries</a>
{% endif %}
```

## Step 4 — Connect with NGO module
In your ngo_routes.py, after approving a request the admin can now
go to /delivery/admin to create a delivery for that request.
The system auto-links via the ngo_request_id.

## All Routes

| Route | Access | Description |
|-------|--------|-------------|
| GET/POST /delivery/track | Public | Track by delivery code |
| GET /delivery/track?code=MS-DEL-2025-0042 | Public | Direct link tracking |
| GET /delivery/my | NGO | View all my deliveries |
| GET /delivery/<id> | NGO/Donor/Admin | Delivery detail + timeline |
| POST /delivery/<id>/confirm_receipt | NGO | Confirm medicines received |
| GET /delivery/admin | Admin | Dashboard + create deliveries |
| POST /delivery/admin/create/<req_id> | Admin | Create delivery for NGO request |
| GET/POST /delivery/admin/<id>/update | Admin | Update delivery status |
| GET /delivery/api/<code> | Any (JSON) | Live status API for polling |

## Delivery Flow

1. Admin approves NGO Request  →  ngo_routes.py
2. Admin goes to /delivery/admin  →  sees "Pending Dispatch" banner
3. Admin clicks "Create Delivery"  →  fills courier details
4. System generates code e.g. MS-DEL-2025-0042
5. Admin shares code with NGO
6. Admin updates: Packed → Dispatched → Out_for_Delivery
7. NGO visits /delivery/track or /delivery/my to follow live
8. NGO clicks "Confirm Receipt" → status = Delivered
9. NGO Request auto-updated to Fulfilled ✅

## Status Stages
Packed → Dispatched → Out_for_Delivery → Delivered
                                       ↘ Failed
